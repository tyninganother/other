# encoding=utf8
from scrapy import cmdline
cmdline.execute("scrapy crawl qiubai".split())